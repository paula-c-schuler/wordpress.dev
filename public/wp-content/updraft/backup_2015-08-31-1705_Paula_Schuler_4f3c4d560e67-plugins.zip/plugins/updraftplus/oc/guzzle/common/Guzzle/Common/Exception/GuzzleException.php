<?php

namespace Guzzle\Common\Exception;

/**
 * Guzzle exception
 */
interface GuzzleException {}
